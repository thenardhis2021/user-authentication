import React from 'react';
import Login from './components/Login';
import Daftar from './components/Daftar';
import Dashboard from './components/Dashboard';
import LupaPassword from './components/LupaPassword';
import ResetPassword from './components/ResetPassword';
import { Route, Switch } from 'react-router-dom';

function App() {
    return (
        <div className="App">
            <Switch>
                <Route exact path="/" component={Login} />
                <Route path="/daftar" component={Daftar} />
                <Route path="/dashboard" component={Dashboard} />
                <Route path="/lupa-password" component={ LupaPassword } />
                <Route path="/resetpassword/:token" component={ ResetPassword } />
            </Switch>
            <Login />
            <Daftar />
        </div>
    );
}

export default App;