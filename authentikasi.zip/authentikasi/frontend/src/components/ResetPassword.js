import axios from 'axios';
import React, { useState } from 'react';

const ResetPassword = () => {
    const[password, setPassword] = useState('');
    const[errorPassword, setErrorPassword] = useState('');
    const[confirmPassword, setConfirmPassword] = useState('');
    const[errorConfirmPassword, setErrorConfirmPassword] = useState('');
    const[alert, setAlert] = useState('');

    const changePassword = (e) => {
        const value = e.target.value
        setPassword(value)
        if(!value) {
            setErrorPassword('confirm password tidak boleh kosong')
        } else {
            setErrorPassword('')
        }
    }

    const changeConfirmPassword = (e) => {
        const value = e.target.value
        setConfirmPassword(value)
        if(!value) {
            setErrorPassword('password tidak boleh kosong')
        } else if(password !=  value) {
            setErrorConfirmPassword('password tidak cocok')
        } else {
            setErrorPassword('')
        }
    }

    const simpan = () => {
        const data = {
            password: password,
            token: props.match.params.token
        }
        axios.put('http://localhost:3001/resetpassword', data)
        .then(res => {
            if(res) {
                setPassword('')
                setConfirmPassword('')
                setAlert('password berhasil diganti')
                setTimeout(() => {
                    setAlert('')
                }, 3000)
            }
        })
    }

    return (
        <div style={{marginTop: '170px'}}>
            <div className="container">
                <div className="row justify-content-center">
                    <div className="col-md-6">
                        <div className="card-body">
                            {
                                alert && (
                                    <div className="alert alert-primary">
                                        {alert}
                                    </div>
                                )
                            }
                            <div className="form-group">
                                <label>New Password</label>
                                <input type="password" placeholder="Masukkan password baru" className="form-control" value={password} onChange={changePassword} />
                                {
                                    errorPassword && (
                                        <p className="text-danger">(errorPassword)</p>
                                    )
                                }
                            </div>
                            <div className="form-group">
                                <label>Confirm Password</label>
                                <input type="password" placeholder="Tulis ulang password" className="form-control" value={confirmPassword} onChange={changeConfirmPassword} />
                                {
                                    errorConfirmPassword && (
                                        <p className="text-danger">(errorConfirmPassword)</p>
                                    )
                                }
                            </div>
                            <button className="btn btn-primary" onClick={simpan}>Simpan</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ResetPassword