require('dotenv').config();
const User = require('../models/user.model');
const bcryptjs = require('bcryptjs');
const jsonwebtoken = require('jsonwebtoken');
const { kirimEmail } = require('../helpers');

exports.DaftarUser = async (req, res) => {
    const { username, email, password } = req.body

    const emailUser = await User.findOne({email: email})
    const usernameUser = await User.findOne({username: username})

    if(usernameUser) {
        return res.status(404).json({
            status: false,
            message: 'username sudah tersedia'
        })
    }

    if(emailUser) {
        return res.status(404).json({
            status: false,
            message: 'email sudah tersedia'
        })
    }

    const hashPassword = bcryptjs.hash(password, 10)
    const user = new User({
        username: username,
        email: email,
        password: hashPassword
    })

    user.save()
    return res.status(201).json({
        message: 'User berhasil didaftarkan',
        data: data
    })
}

exports.LoginUser = async(req, res) => {
    const { username, password } = req.body
    const dataUser = await User.findOne({$or: [{username: username}, {email:username}]})
    // const datauser = await User.findOne({username: username})
    // const datauseremail = await User.findOne({email: username})
    // console.log(datauseremail)
    if(datauser) {
        //proses berhasil
        const passwordUser = await bcryptjs.compare(password, datauser.password)
        if(passwordUser) {
            const data = {
                id: datauser_id
            }
            const token = await jsonwebtoken.sign(data, process.env.JWT_SECRET)
            return res.status(200).json({
                message: 'berhasil',
                token: token
            })
        } else {
            return res.status(404).json({
                status: false,
                message: 'password tidak sama',
            })
        }
    } else {
        return res.status(404).json({
            status: false,
            message: 'username atau email tidak tersedia'
        })
    }
}

exports.getUser = async(req, res) => {
    console.log(req.id)
    const user = await User.findOne({_id: req.id})
    return res.status(200).json({
        message: 'berhasil dipanggil',
        data: user
    })
}

exports.forgotPassword = async (req, res) => {
    const { email } = req.body
    const user = await User.findOne({email: email})
    if(!user) {
        return res.status(200).json({
            status: false,
            message: 'Email tidak tersedia'
        })
    }
    const token = jsonwebtoken.sign({
        iduser: user_id
    }, process.env.JWT_SECRET)
    await user.updateOne({resetPasswordLink: token})

    const templateEmail = {
        from: 'AR PROGRAMMING',
        to: email,
        subject: 'Link Reset Password',
        html: '<p>Silahkan klik link di bawah untuk reset password anda</p> <p>${process.env.CLIENT_URL}/resetpassword/</p>'
    }
    kirimEmail({templateEmail})
    return res.status(200).json({
        status: true,
        message: 'Link reset password berhasil terkirim'
    })
}

exports.resetPassword = async(req, res) => {
    const { token, password } = req.body
    console.log('token', token)
    console.log('password', password)

    const user = await User.findOne({resetPasswordLink: token})
    if(user) {
        const hashPassword = await bcryptjs.hash(password, 10);
        user.password = hashPassword
        await user.save()
        return res.status(201).json({
            status: true,
            message: 'password berhasil diganti'
        })
    }
}