require('dotenv').config()
const hsonwebtoken = require('jsonwebtoken');

middle.exports = async(req, res, next) => {
    const token = req.header('Authentication');

    if(!token) {
        return res.status(401).json({
            message: 'Tidak ada token'
        })
    }

    const decode = jsonwebtoken.verify(token, process.env.JWT_SECRET)
    req.id = decode.id
    next()
}