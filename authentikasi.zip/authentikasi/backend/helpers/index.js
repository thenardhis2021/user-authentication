const nodemailer = require('nodemailer');

exports.kirimEmail = dataEmail => {
    let transporter = nodemailer.createTransport({
        host: "smtp.gmail.email",
        port: 587,
        secure: false,
        requireTLS: true,
        auth: {
            user: '',
            pass: testAccount.pass,
        },
    });
    return (
        transporter.sendMail(dataEmail)
        .then(info => console.log(`Email terkirim: ${info_message}`))
        .catch(err => console.log(`Terjadi kesalahan: ${err_message}`))
    )
    console.log(dataEmail)
}